document.getElementById("loginButton").addEventListener("click", loginButton);


function loginButton () {
    window.location="table.html";
}