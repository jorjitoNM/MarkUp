var infos = document.querySelectorAll('.getInfo');

for ( var i=0;i<infos.length;i++) {
    infos[i].addEventListener("click", function () {
        alert("Info");
    })
}
var infos = document.querySelectorAll('.delete');

for ( var i=0;i<infos.length;i++) {
    infos[i].addEventListener("click", function () {
        alert("Delete");
    })
}
var infos = document.querySelectorAll('.update');

for ( var i=0;i<infos.length;i++) {
    infos[i].addEventListener("click", function () {
        alert("Upadte");
    })
}